'use strict';

/**
 * @ngdoc function
 * @name miappApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the miappApp
 */
angular.module('miappApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
